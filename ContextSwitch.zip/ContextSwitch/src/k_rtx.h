#ifndef _K_RTX_H_
#define _K_RTX_H_
int k_release_processor(void);
#endif /* ! _K_RTX_H_ */
